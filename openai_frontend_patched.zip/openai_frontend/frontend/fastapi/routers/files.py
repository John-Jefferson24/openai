from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
import os, uuid, pathlib

router = APIRouter()

ROOT = os.getenv("FILESTORE_ROOT", "/tmp/triton_openai_files")
pathlib.Path(ROOT).mkdir(parents=True, exist_ok=True)

@router.get("/v1/files/{fid:path}/content")
def get_file(fid: str):
    fp = os.path.join(ROOT, fid)
    if not os.path.isfile(fp):
        raise HTTPException(status_code=404, detail="Not found")
    mime = "image/png" if fp.endswith(".png") else "application/octet-stream"
    with open(fp, "rb") as f:
        data = f.read()
    return Response(content=data, media_type=mime)
