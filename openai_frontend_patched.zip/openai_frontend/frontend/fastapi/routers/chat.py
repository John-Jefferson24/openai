#
    # Early image path: proxy to local vLLM OpenAI server if configured
    if _has_image_parts(request):
        if VLLM_OPENAI_BASE == "disabled":
            raise HTTPException(status_code=400, detail="Image inputs are not supported on this deployment (set VLLM_OPENAI_BASE to enable).")
        try:
            r = requests.post(
                f"{VLLM_OPENAI_BASE}/chat/completions",
                json=request.model_dump(mode="json"),
                stream=True,
                timeout=300,
            )
        except requests.RequestException as e:
            raise HTTPException(status_code=502, detail=f"Image backend unreachable: {e}")
        return StreamingResponse(
            r.iter_content(chunk_size=8192),
            media_type=r.headers.get("content-type","application/json"),
            status_code=r.status_code,
        )
 Copyright 2024, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#  * Neither the name of NVIDIA CORPORATION nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

from fastapi import APIRouter, HTTPException, Request
import os, requests
from fastapi.responses import StreamingResponse
from fastapi.responses import StreamingResponse
from schemas.openai import CreateChatCompletionRequest, CreateChatCompletionResponse

VLLM_OPENAI_BASE = os.getenv("VLLM_OPENAI_BASE", "disabled").strip()

def _has_image_parts(request: CreateChatCompletionRequest) -> bool:
    for m in (request.messages or []):
        parts = getattr(m, "content", None)
        if isinstance(parts, list):
            for p in parts:
                t = getattr(p.root, "type", None)
                if t in ("image_url", "input_image"):
                    return True
    return False


router = APIRouter()


@router.post(
    "/v1/chat/completions", response_model=CreateChatCompletionResponse, tags=["Chat"]
)
async def create_chat_completion(
    request: CreateChatCompletionRequest,
    raw_request: Request,
) -> CreateChatCompletionResponse | StreamingResponse:
    """
    Creates a chat completion for the provided messages and parameters.
    """
    if not raw_request.app.engine:
        raise HTTPException(status_code=500, detail="No attached inference engine")

    try:
        response = await raw_request.app.engine.chat(request)
        if request.stream:
            return StreamingResponse(response, media_type="text/event-stream")
        return response
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"{e}")
