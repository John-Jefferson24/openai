import os, base64

MAX_IMAGE_BYTES = int(os.getenv('MEDIA_MAX_IMAGE_BYTES', '5000000'))
ALLOWED = set((os.getenv('MEDIA_MIME_ALLOW', 'image/jpeg,image/png,image/webp')).split(','))

def preflight_input_image_part(part: dict):
    if part.get('type') != 'input_image':
        return
    img = part.get('image', {})
    mime = (img.get('mime_type') or '').lower()
    data = img.get('data') or ''
    if mime not in ALLOWED:
        raise ValueError(f'Unsupported image mime: {mime}')
    if int(len(data) * 0.75) > MAX_IMAGE_BYTES:
        raise ValueError('Image too large (precheck)')
    raw = base64.b64decode(data)
    if len(raw) > MAX_IMAGE_BYTES:
        raise ValueError('Image too large')
